# Things to check:

rm(list = ls(all = TRUE))
gc()

options(scipen = 999)
options(show.error.locations=TRUE)
options(warn=1)

library(data.table)
library(futile.logger)
library(checkmate)
library(lfe)
library(ggplot2)
library(scales)
library(parallel)
library(eventStudy)

my_dt <- readRDS("~/Downloads/old_downloads/ES_testing/testdt.rds")
my_dt[tax_yr < win_yr, gross_winnings_adj_equiv := 0]
my_dt[, keep_case := between(age, 21, 64, incbounds = TRUE)]
my_dt[, check_weights := 1]

collapse_table <- data.table(a = c("name1","name2", "name3"),b = c(list(-7:-1), list(1), list(2:5)))

# First without covariates
print("Estimating Model 1a -- no covariates; no endogeneous variables; no selection criteria")
set.seed(1)
res1a <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE)

set.seed(1)
res2a <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE)

gc()

######

# Without covariates, but adding endog var
print("Estimating Model 1a2 -- no covariates; ADD endogeneous variables; no selection criteria")
set.seed(1)
res1a2 <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  endog_var = "gross_winnings_adj_equiv")

set.seed(1)
res2a2 <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  endog_var = "gross_winnings_adj_equiv")

gc()

######

# Now with covariates (but no endogenous variable)
print("Estimating Model 1b -- add discrete covariate; no endogeneous variables; no selection criteria")
set.seed(1)
res1b <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age")

set.seed(1)
res2b <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age")

gc()

######

# Now with covariates and endogs
print("Estimating Model 1c -- add discrete covariate; add endogeneous variable; no selection criteria")
set.seed(1)
res1c <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age",
  endog_var = "gross_winnings_adj_equiv")

set.seed(1)
res2c <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age",
  endog_var = "gross_winnings_adj_equiv")

gc()

######

# Now with endogs and a selection rule (but not covariates)
print("Estimating Model 1d0 -- no covariates; add endogeneous variable; add selection criterionn")
set.seed(1)
res1d0 <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  endog_var = "gross_winnings_adj_equiv",
  control_subset_var = "keep_case",
  control_subset_event_time = 0,
  treated_subset_var = "keep_case",
  treated_subset_event_time = 0)

set.seed(1)
res2d0 <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  endog_var = "gross_winnings_adj_equiv",
  control_subset_var = "keep_case",
  control_subset_event_time = 0,
  treated_subset_var = "keep_case",
  treated_subset_event_time = 0)

gc()

######

# Now with covariates and endogs and a selection rule
print("Estimating Model 1d -- add discrete covariate; add endogeneous variable; add selection criterionn")
set.seed(1)
res1d <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age",
  endog_var = "gross_winnings_adj_equiv",
  control_subset_var = "keep_case",
  control_subset_event_time = 0,
  treated_subset_var = "keep_case",
  treated_subset_event_time = 0)

set.seed(1)
res2d <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age",
  endog_var = "gross_winnings_adj_equiv",
  control_subset_var = "keep_case",
  control_subset_event_time = 0,
  treated_subset_var = "keep_case",
  treated_subset_event_time = 0)

gc()

######

# Now with covariates and endogs and a selection rule, but covariates adjusted with IPW
print("Estimating Model 1e -- add discrete covariate (with IPW); add endogeneous variable; add selection criterionn")
set.seed(1)
res1e <- Wald_ES(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age",
  endog_var = "gross_winnings_adj_equiv",
  control_subset_var = "keep_case",
  control_subset_event_time = 0,
  treated_subset_var = "keep_case",
  treated_subset_event_time = 0,
  ipw = TRUE,
  ipw_model = "linear",
  ipw_keep_data = TRUE)

set.seed(1)
res2e <- Wald_ES2(
  long_data = copy(my_dt),
  outcomevar = "db_w2_wages",
  unit_var = "tin",
  cluster_vars = "tin",
  cal_time_var = "tax_yr",
  onset_time_var = "win_yr",
  omitted_event_time = -2,
  homogeneous_ATT = FALSE,
  calculate_collapse_estimates = TRUE,
  collapse_inputs = collapse_table,
  cohort_by_cohort = FALSE,
  cohort_by_cohort_num_cores = 1,
  bootstrapES = TRUE,
  bootstrap_iters = 2,
  bootstrap_num_cores = 1,
  keep_all_bootstrap_results = TRUE,
  heterogeneous_only = TRUE,
  discrete_covars = "age",
  endog_var = "gross_winnings_adj_equiv",
  control_subset_var = "keep_case",
  control_subset_event_time = 0,
  treated_subset_var = "keep_case",
  treated_subset_event_time = 0,
  ipw = TRUE,
  ipw_model = "linear",
  ipw_keep_data = TRUE)

gc()

###
# CHECKING THAT THE RESULTS ARE IDENTICAL

# Vanilla run -- no covariates and no endog var
print(identical(res1a, res2a)) # TRUE

# Vanilla run -- no covariates, but now with an endog var
print(identical(res1a2, res2a2)) # TRUE

# Now with covariates (but no endog)
print(identical(res1b, res2b)) # TRUE

# Now with covariates and endogs
print(identical(res1c, res2c)) # TRUE

# Now with endogs and a selection criterion (but not covariates)
print(identical(res1d0, res2d0)) # TRUE

# Now with covariates and endogs and a selection criterion
print(identical(res1d, res2d)) # FALSE

identical(res1d[[1]], res2d[[1]]) # TRUE
identical(res1d[[2]], res2d[[2]]) # TRUE
identical(res1d[[3]], res2d[[3]]) # TRUE
identical(res1d[[4]], res2d[[4]]) # TRUE
identical(res1d[[5]], res2d[[5]]) # TRUE
identical(res1d[[6]], res2d[[6]]) # TRUE
identical(res1d[[7]], res2d[[7]]) # FALSE
all.equal(res1d[[7]], res2d[[7]], tol = 10^-20)
# the culprit is likely a different omitted category for the age FEs; not worth dwelling on since the full results were unchanged

# Now with covariates and endogs and a selection criterion, and covariates are adjusted through IPW
print(identical(res1e, res2e)) # TRUE






